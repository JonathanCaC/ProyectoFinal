package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Reserva;
import util.ConexionDB;


public class ReservaDAO {
    public void addReserva(Reserva reserva) {
        String sql = "INSERT INTO reserva (nombre, apellido, correo, pelicula, cant_entradas, fecha_reserva) VALUES (?, ?, ?, ?, ?, ?)";
        //bloque try-with-resources
        //asegura que los recursos abiertos en su declaración (dentro de los paréntesis) se cierren automáticamente al final del bloque try 
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, reserva.getNombre());
            pstmt.setString(2, reserva.getApellido());
            pstmt.setString(3, reserva.getCorreo());
            pstmt.setString(4, reserva.getPelicula());
            pstmt.setString(5, reserva.getCantEntradas());
            pstmt.setDate(6, reserva.getFechaReserva());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Reserva obtPorCodReserva(int id) {
        String sql = "SELECT * FROM reserva WHERE codigo_de_reserva = ?";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                Reserva reserva = new Reserva();
                reserva.setCodReserva(rs.getInt("codigo_de_reserva"));
                reserva.setNombre(rs.getString("nombre"));
                reserva.setApellido(rs.getString("apellido"));
                reserva.setCorreo(rs.getString("correo"));
                reserva.setPelicula(rs.getString("pelicula"));
                reserva.setCantEntradas(rs.getString("cant_entradas"));
                reserva.setFechaReserva(rs.getDate("fecha_reserva"));
                return reserva;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Reserva> obtTodos() {
        List<Reserva> reservas = new ArrayList<>();
        String sql = "SELECT * FROM reserva";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Reserva reserva = new Reserva();
                reserva.setCodReserva(rs.getInt("codigo_de_reserva"));
                reserva.setNombre(rs.getString("nombre"));
                reserva.setApellido(rs.getString("apellido"));
                reserva.setCorreo(rs.getString("correo"));
                reserva.setPelicula(rs.getString("pelicula"));
                reserva.setCantEntradas(rs.getString("cant_entradas"));
                reserva.setFechaReserva(rs.getDate("fecha_reserva"));
                reservas.add(reserva);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reservas;
    }

    public void refreshReserva(Reserva reserva) {
        String sql = "UPDATE reserva SET nombre = ?, apellido = ?, correo = ?, pelicula = ?, cant_entradas = ?, fecha_reserva = ? WHERE codigo_de_reserva = ?";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, reserva.getNombre());
            pstmt.setString(2, reserva.getApellido());
            pstmt.setString(3, reserva.getCorreo());
            pstmt.setString(4, reserva.getPelicula());
            pstmt.setString(5, reserva.getCantEntradas());
            pstmt.setDate(6, reserva.getFechaReserva());
            pstmt.setInt(7, reserva.getCodReserva());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminarReserva(int id) {
        String sql = "DELETE FROM reserva WHERE codigo_de_reserva = ?";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

