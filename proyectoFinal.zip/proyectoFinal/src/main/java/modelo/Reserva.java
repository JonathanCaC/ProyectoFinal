package modelo;

import java.sql.Date;

public class Reserva {
    private int codReserva;
    private String nombre;
    private String apellido;
    private String correo;
    private String pelicula;
    private String cantEntradas;
    private Date fechaReserva;

    public Reserva() {
    }

    public int getCodReserva() {
        return codReserva;
    }

    public void setCodReserva(int codReserva) {
        this.codReserva = codReserva;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPelicula() {
        return pelicula;
    }

    public void setPelicula(String pelicula) {
        this.pelicula = pelicula;
    }

    public String getCantEntradas() {
        return cantEntradas;
    }

    public void setCantEntradas(String cantEntradas) {
        this.cantEntradas = cantEntradas;
    }

    public Date getFechaReserva() {
        return fechaReserva;
    }

    public void setFechaReserva(Date fechaReserva) {
        this.fechaReserva = fechaReserva;
    }

 
    
}
