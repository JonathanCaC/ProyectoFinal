package controlador;

import dao.ReservaDAO;
import modelo.Reserva;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;

@WebServlet("/registroReserva")
public class RegistroReserva extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener datos del formulario
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String correo = request.getParameter("correo");
        String pelicula = request.getParameter("pelicula");
        String cantEntradas = request.getParameter("cant_entradas");

        // Crear un objeto Reserva con los datos
        Reserva reserva = new Reserva();
        reserva.setNombre(nombre);
        reserva.setApellido(apellido);
        reserva.setCorreo(correo);
        reserva.setPelicula(pelicula);
        reserva.setCantEntradas(cantEntradas);

        // Obtener la fecha actual
        java.util.Date fechaActual = new java.util.Date(); //es una forma de utilizar la clase sin necesitar una declaracion 'import'
        reserva.setFechaReserva(new Date(fechaActual.getTime()));

        // Agregar la reserva a la base de datos
        ReservaDAO reservaDAO = new ReservaDAO();
        reservaDAO.addReserva(reserva);

        // Redireccionar a la página de visualización de reservas
        response.sendRedirect(request.getContextPath() + "/verReservas.jsp");
    }
}
