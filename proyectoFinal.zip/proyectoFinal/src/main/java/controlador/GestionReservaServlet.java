package controlador;

import dao.ReservaDAO;
import modelo.Reserva;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;

@WebServlet("/GestionReservaServlet")
public class GestionReservaServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accion = request.getParameter("accion");
        ReservaDAO reservasDAO = new ReservaDAO();

        // Inicializar idReserva antes del switch para que esté disponible en todos los casos
        int idReserva = Integer.parseInt(request.getParameter("id"));

        switch (accion) {
            case "actualizar":
                Reserva reserva = reservasDAO.obtPorCodReserva(idReserva);
                request.setAttribute("reserva", reserva); //Esto permite pasar datos del servlet a una vista (como un archivo JSP) o a otro servlet al que se redirige o se reenvía la solicitud
                request.getRequestDispatcher("actualizar.jsp").forward(request, response);
                break;
            case "confirmarActualizacion":
                Reserva reservaActualizado = new Reserva();
                reservaActualizado.setCodReserva(idReserva);
                reservaActualizado.setNombre(request.getParameter("nombre"));
                reservaActualizado.setApellido(request.getParameter("apellido"));
                reservaActualizado.setCorreo(request.getParameter("correo"));
                reservaActualizado.setPelicula(request.getParameter("pelicula"));
                reservaActualizado.setCantEntradas(request.getParameter("cant_entradas"));
                // Asume que el método setFechaAlta acepta un java.sql.Date
                reservaActualizado.setFechaReserva(java.sql.Date.valueOf(request.getParameter("fecha_reserva")));

                reservasDAO.refreshReserva(reservaActualizado);
                response.sendRedirect("gestionReservas.jsp");
                break;
            case "eliminar":
                reservasDAO.eliminarReserva(idReserva);
                response.sendRedirect("gestionReservas.jsp");
                break;
            default:
                response.sendRedirect("gestionReservas.jsp");
                break;
        }
    }
}

